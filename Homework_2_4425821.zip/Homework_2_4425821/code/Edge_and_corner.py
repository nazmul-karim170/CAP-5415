
import numpy as np
from PIL import Image
from convolution import convolution

k = 0.05
threshold = 45

## import the image and convert ti to an array
image_interest  = np.asarray(Image.open('download_1.jpeg'))
height, width = image_interest.shape[0], image_interest.shape[1]

## Kernel matrix for edges detection
kernel_x = np.array([[1, 0, -1],
                     [2, 0, -2],
                     [1, 0, -1]])     ## Vertical edge detection
kernel_y = np.array([[1, 2, 1],
                     [0, 0, 0],
                     [-1, -2, -1]])   ## Horizontal Edge detection
 
filter_height_x, filter_width_x  = kernel_x.shape[0], kernel_x.shape[1]
filter_height_y, filter_width_y  = kernel_y.shape[0], kernel_y.shape[1]

## Output for convolution to be carried out in the x and y axis
conv_output_x = np.zeros((width-filter_height_x+1,width-filter_width_x +1))
conv_output_y = np.zeros((width-filter_height_y+1,width-filter_width_y +1))

conv_output_x = convolution(kernel_x,image_interest,1)
conv_output_y = convolution(kernel_y,image_interest,0)

## save the x and y component of the edges
output_x = Image.fromarray(conv_output_x.astype(np.uint8))
output_x.save('out_x_edge.jpg')
output_y = Image.fromarray(conv_output_y.astype(np.uint8))
output_y.save('out_y_edge.jpg')


            ### Sobel Edge Detection ####

# Resultant Component
conv_output = np.sqrt(conv_output_x**2 + conv_output_y**2)

## Normalization
conv_output = (conv_output - np.min(conv_output))
conv_output = (conv_output/np.max(conv_output))*255

## Final output
output_final = np.zeros((conv_output.shape), dtype='uint8')
output_final[conv_output > threshold] = 255

## Saving the image
output_to_save = Image.fromarray(output_final.astype(np.uint8))
output_to_save.save('out_edge_sobel.jpg')



                #### Harris Corner Detection ####

## Obtain the components for calculating matrix components
xx = np.multiply(conv_output_x,conv_output_x)
yy = np.multiply(conv_output_y,conv_output_y)
xy = np.multiply(conv_output_x,conv_output_y)

## Matrix components
com_xx = convolution(np.ones((5,5)),xx,1)
com_yy = convolution(np.ones((5,5)),yy,0)
com_xy = convolution(np.ones((5,5)),xy,0)


## initialization of R-values
out_coef   = np.zeros((com_xx.shape[0],com_xx.shape[1]))


## Calculate the R-values
for y in range(0,com_xx.shape[0]):
    for x in range(0,com_xx.shape[1]):
        out_coef[y,x] = ( (com_xx[y,x]*com_yy[y,x]) - com_xy[y,x]**2) - k*((com_xx[y,x]+com_yy[y,x])**2)

## Initialization of Final Signal coefficient
final_sig = np.zeros((out_coef.shape), dtype='uint8')

## Apply thresholding
final_sig[out_coef>25000000000] = 255

## Saving the image
output_to_save = Image.fromarray(final_sig.astype(np.uint8))
output_to_save.save('out_new.jpg')


