import numpy as np

def convolution(conv_filter,image, axis):

    ## Dimesnion of the image and
    height, width = image.shape[0], image.shape[1]
    filter_height, filter_width  = conv_filter.shape[0], conv_filter.shape[1]
    # padding = (filter_width-1)//2



    ## output of the convolution without padding
    output = np.zeros((height-filter_height+1, width-filter_width+1), dtype="float32")

    for y in np.arange(0, height-filter_height+1):
        for x in np.arange(0, width-filter_width+1):
            image_partial = image[y:y + filter_height, x:x + filter_width]
            int_out = (image_partial*conv_filter).sum()
            output[y, x] = int_out

    return output

