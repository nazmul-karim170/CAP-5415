import glob
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from convolution import convolution
from sklearn.metrics import confusion_matrix

k =0.07

## Length of the training and testing set
train_length = 50
test_length = 50
n_features = 20
train_set = 10 * train_length
test_set = 10 * test_length


x_train = np.zeros((train_set, 28, 28))
x_test = np.zeros((test_set, 28, 28))
l =0
t = 0
for i in range(0,10):

    ## Get the file from folder 
    image_file = glob.glob(str(i)+'/*.png')

    ## Train and test file images
    image_file_train = image_file[0:train_length]
    image_file_test = image_file[100-test_length:100]

    for f in image_file_train:
    	x_train[l] = np.array(Image.open(f))
    	l += 1

    for f in image_file_test:
    	x_test[t]  = np.array(Image.open(f))
    	t +=  1

## initialize
R_value_train = np.zeros((n_features,train_set))
R_train = np.zeros((n_features,train_set))

R_value_test = np.zeros((n_features,test_set))

## Kernel matrix for edges detection
kernel_x = np.array([[1, 0, -1],
                     [2, 0, -2],
                     [1, 0, -1]])     ## Vertical edge detection
kernel_y = np.array([[1, 2, 1],
                     [0, 0, 0],
                     [-1, -2, -1]])   ## Horizontal Edge detection

filter_height_x, filter_width_x  = kernel_x.shape[0], kernel_x.shape[1]
filter_height_y, filter_width_y  = kernel_y.shape[0], kernel_y.shape[1]
height = width = 28


## for training set
for p in range(train_set):

	## Output for convolution to be carried out in the x and y axis
	conv_output_x = np.zeros((width-filter_height_x+1,width-filter_width_x +1))
	conv_output_y = np.zeros((width-filter_height_y+1,width-filter_width_y +1))

	conv_output_x = convolution(kernel_x,x_train[p],1)
	conv_output_y = convolution(kernel_y,x_train[p],0)

	## Obtain the components for calculating matrix components
	xx = np.multiply(conv_output_x,conv_output_x)
	yy = np.multiply(conv_output_y,conv_output_y)
	xy = np.multiply(conv_output_x,conv_output_y)

	## Matrix components
	com_xx = convolution(np.ones((5,5)),xx,1)
	com_yy = convolution(np.ones((5,5)),yy,0)
	com_xy = convolution(np.ones((5,5)),xy,0)


	## initialization of R-values
	Hessian = np.zeros((com_xx.shape[0],com_xx.shape[1],2,2))
	eig_value = np.zeros((com_xx.shape[0],com_xx.shape[1],2))
	R   = np.zeros((com_xx.shape[0],com_xx.shape[1]))


	## Calculate the R-values
	for y in range(0,com_xx.shape[0]):
	    for x in range(0,com_xx.shape[1]):
	        R[y,x] = ((com_xx[y,x]*com_yy[y,x]) - com_xy[y,x]**2) - k*((com_xx[y,x]+com_yy[y,x])**2)

	R = R.reshape(R.size)

	## Take the 10 most positive and 10 most negative values
	R = np.sort(R) 
	R_value_train[:,p]= np.delete(R, range(10,R.size-10))


for p in range(test_set):

	## Output for convolution to be carried out in the x and y axis
	conv_output_x = np.zeros((width-filter_height_x+1,width-filter_width_x +1))
	conv_output_y = np.zeros((width-filter_height_y+1,width-filter_width_y +1))

	conv_output_x = convolution(kernel_x,x_test[p],1)
	conv_output_y = convolution(kernel_y,x_test[p],0)

	## Obtain the components for calculating matrix components
	xx = np.multiply(conv_output_x,conv_output_x)
	yy = np.multiply(conv_output_y,conv_output_y)
	xy = np.multiply(conv_output_x,conv_output_y)

	## Matrix components
	com_xx = convolution(np.ones((5,5)),xx,1)
	com_yy = convolution(np.ones((5,5)),yy,0)
	com_xy = convolution(np.ones((5,5)),xy,0)

	## initialization of R-values
	Hessian = np.zeros((com_xx.shape[0],com_xx.shape[1],2,2))
	eig_value = np.zeros((com_xx.shape[0],com_xx.shape[1],2))
	R   = np.zeros((com_xx.shape[0],com_xx.shape[1]))

	## Calculate the R-values
	for y in range(0,com_xx.shape[0]):
	    for x in range(0,com_xx.shape[1]):
	        R[y,x] = ((com_xx[y,x]*com_yy[y,x]) - com_xy[y,x]**2) - k*((com_xx[y,x]+com_yy[y,x])**2)

	R = R.reshape(R.size)

	## Take the 10 most positive and 10 most negative values
	R = np.sort(R)
	R_value_test[:,p]= np.delete(R, range(10,R.size-10))
    
    
## Initialization 
training_lab = np.zeros((10*train_length, 10))
test_label = np.zeros((10*test_length, 10))
mu = np.zeros((n_features,10))
weight = np.zeros((n_features,10))
bias = np.zeros((1,10))
number_classes= 10


# parameters of normal distribution
for i in range(number_classes):
    mu[:,i] = np.transpose((1/train_length) * np.sum(R_value_train[:,(train_length*i):(train_length*(i+1))],1))

mu_all = np.transpose((1/train_length*number_classes) * np.sum(R_value_train,1)).reshape(20,1)
sigma = (1/(train_length*number_classes)) * np.dot( (R_value_train-mu_all) , np.transpose(R_value_train-mu_all))


## Weights and biases for classifier
for i in range(0,10):
    weight[:,i] = np.dot(np.linalg.pinv(sigma),mu[:,i])
    bias[0,i] = -0.5 * (np.dot(np.dot(np.transpose(mu[:,i]),np.linalg.pinv(sigma)) , mu[:,i]))


## Training label and test label
training_lab = np.dot(np.transpose(R_value_train),weight) + bias
test_label = np.dot(np.transpose(R_value_test),weight) + bias


## Training and Test Classes label
train_class = np.argmax(training_lab,axis=1)
test_class = np.argmax(test_label,axis=1)

print(train_class)

# true_label =np.array([np.array(i* np.ones(50)) for i in range(10)])

true_label = np.zeros((50))

for i in range(1,10):
    true_label = np.append(true_label,i*np.ones((50)))


## Calculate Accuracies
training_accuarcy = (np.sum(train_class == true_label)/500)*100
Testing_accuracy= (np.sum(test_class == true_label)/500)*100

print("Train accuracy", training_accuarcy)
print("test Accuracy", Testing_accuracy)

## Confusion matrices
conf_train = confusion_matrix(train_class.flatten(), true_label.flatten())
conf_test = confusion_matrix(test_class.flatten(), true_label.flatten())

print("Confusion matrix for training set", conf_train)
print("Confusion matrix for test set", conf_test)

