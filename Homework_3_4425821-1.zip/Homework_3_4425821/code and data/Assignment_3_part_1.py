
import numpy as np
from PIL import Image
from convolution import convolution
from sklearn.metrics import confusion_matrix



k = 0.055
threshold = 45

## import the image and convert ti to an array
image_interest  = np.asarray(Image.open('input_2.jpeg'))
height, width = image_interest.shape[0], image_interest.shape[1]

## Kernel matrix for edges detection
kernel_x = np.array([[1, 0, -1],
                     [2, 0, -2],
                     [1, 0, -1]])     ## Vertical edge detection
kernel_y = np.array([[1, 2, 1],
                     [0, 0, 0],
                     [-1, -2, -1]])   ## Horizontal Edge detection
 
filter_height_x, filter_width_x  = kernel_x.shape[0], kernel_x.shape[1]
filter_height_y, filter_width_y  = kernel_y.shape[0], kernel_y.shape[1]

## Output for convolution to be carried out in the x and y axis
conv_output_x = np.zeros((width-filter_height_x+1,width-filter_width_x +1))
conv_output_y = np.zeros((width-filter_height_y+1,width-filter_width_y +1))

conv_output_x = convolution(kernel_x,image_interest,1)
conv_output_y = convolution(kernel_y,image_interest,0)

## save the x and y component of the edges
# output_x = Image.fromarray(conv_output_x.astype(np.uint8))
# output_x.save('out_x_edge.jpg')
# output_y = Image.fromarray(conv_output_y.astype(np.uint8))
# output_y.save('out_y_edge.jpg')


            ### Sobel Edge Detection ####

# Resultant Component
conv_output = np.sqrt(conv_output_x**2 + conv_output_y**2)

## Normalization
conv_output = (conv_output - np.min(conv_output))
conv_output = (conv_output/np.max(conv_output))*255

## Final output
output_final = np.zeros((conv_output.shape), dtype='uint8')
output_final[conv_output > threshold] = 255

## Saving the image
# output_to_save = Image.fromarray(output_final.astype(np.uint8))
# output_to_save.save('out_edge_sobel.jpg')



                #### Harris Corner Detection ####

## Obtain the components for calculating matrix components
xx = np.multiply(conv_output_x,conv_output_x)
yy = np.multiply(conv_output_y,conv_output_y)
xy = np.multiply(conv_output_x,conv_output_y)

## Matrix components
com_xx = convolution(np.ones((5,5)),xx,1)
com_yy = convolution(np.ones((5,5)),yy,0)
com_xy = convolution(np.ones((5,5)),xy,0)


## initialization of R-values
Hessian = np.zeros((com_xx.shape[0],com_xx.shape[1],2,2))
eig_value = np.zeros((com_xx.shape[0],com_xx.shape[1],2))
R   = np.zeros((com_xx.shape[0],com_xx.shape[1]))


## Calculate the R-values
for y in range(0,com_xx.shape[0]):
    for x in range(0,com_xx.shape[1]):

        ## Hessian and eigenvalues
        Hessian = [[com_xx[y,x], com_xy[y,x]], [com_xy[y,x], com_yy[y,x]]]
        eig_value[y,x,:] = np.linalg.eigvals(Hessian)

        ## R-values
        R[y,x] = ((com_xx[y,x]*com_yy[y,x]) - com_xy[y,x]**2) - k*((com_xx[y,x]+com_yy[y,x])**2)



## Apply thresholding
Rv_1 = np.zeros((R.shape), dtype='uint8')
Rv_2 = np.zeros((R.shape), dtype='uint8')
Rv_3 = 255*np.ones((R.shape), dtype='uint8')

## Corner detection
Rv_1[R>450000000000] = 255

## Edge detection
Rv_2[R<-250000000000] = 255

## Flat Region Detction
Rv_3[R>450000000000] = 0
Rv_3[R<-250000000000] = 0


### Local Maxima detection for the corners
ID = np.zeros((Rv_1.shape))
step = 20

for x in range(0, com_xx.shape[0]):
    for y in range(0, com_xx.shape[1]):

        if Rv_1[x, y] == 255 and ID[x, y] == 0:

            ## R-score for the selected area
            ROI = R[x:x + step, y:y +step]
            
            ## indices of the largest score
            ind_max = np.unravel_index(np.argmax(ROI, axis=None), ROI.shape)

            ## Assigning the proper values
            Rv_1[x:x + step, y:y + step] = 0
            Rv_1[ind_max[0] + x, ind_max[1] + y] = 255
            ID[x:x + step, y:y + step] = 1


# Keeping the counts of corners, edge and flat
corner_count = np.count_nonzero(Rv_1)
edge_count = np.count_nonzero(Rv_2)
flat_count = R.size - corner_count - edge_count 


## Initialization of feature vectors for corner, edge and flat region
corner_weight = np.zeros((corner_count, 2))
edge_weight = np.zeros((edge_count, 2))
flat_weight = np.zeros((flat_count, 2))
all_weight = np.zeros((R.size, 2))



# ground  = np.zeros((R.shape[0], R.shape[1]))
ground_truth = np.zeros((R.shape))
p = q= r = s = 0

## Get the true label of corner, edge and flat class/region 
for i in range(0, com_xx.shape[0]):
    for j in range(0, com_xx.shape[1]):
        all_weight[p] = eig_value[i, j, :].reshape(2)
        
        ## true label of corners (Class-1 )
        if Rv_1[i, j] == 255:
            corner_weight[q] = all_weight[p]
            ground_truth[i, j] = 0
            q += 1

        ## true label of edge (Class-2)
        elif Rv_2[i, j] == 255:
            edge_weight[r] = all_weight[p]
            ground_truth[i, j] = 1
            r += 1

        ## True label of flat region (Class-3)
        elif Rv_3[i, j] == 255:
            # print(s, p)
            flat_weight[s] = all_weight[p]
            ground_truth[i, j] = 2
            s += 1
        p += 1


            ## Mean vectors for each class ##
corner_mean = np.transpose((1 / corner_count) * np.sum(corner_weight, 0)).reshape(1, 2)
edge_mean = np.transpose((1 / edge_count) * np.sum(edge_weight, 0)).reshape(1, 2)
flat_mean = np.transpose((1 / flat_count) * np.sum(flat_weight, 0)).reshape(1, 2)
total_mean = np.transpose((1 / R.size) * np.sum(all_weight, 0)).reshape(1,2)


        ### Covariance Matrix of corners, edge and flat region #### 
corner_sigma = (1/corner_count) * np.dot(np.transpose(corner_weight-corner_mean), corner_weight-corner_mean)
flat_sigma = (1/flat_count) * np.dot(np.transpose(flat_weight-flat_mean), flat_weight-flat_mean )
edge_sigma = (1/edge_count) * np.dot(np.transpose(edge_weight-edge_mean), edge_weight-edge_mean )


        ## Covariance Matrix for all of them ###
sigma = (1 / R.size) * np.dot(np.transpose(all_weight - total_mean), (all_weight - total_mean))


## Certain Weights for all 3 classifiers
corner_w = -0.5*np.log(np.linalg.det(corner_sigma))
edge_w = -0.5*np.log(np.linalg.det(edge_sigma))
flat_w = -0.5*np.log(np.linalg.det(flat_sigma))



## Initialize array for parameter and predicted label
predicted_label = np.zeros((R.shape))
parmeter_dist = np.zeros((3))


## 

edge_label = np.zeros((R.shape), dtype='uint8')
flat_label = np.zeros((R.shape), dtype='uint8')
final_prediction = np.zeros((3, R.shape[0], R.shape[1]), dtype='uint8')
false_count = np.zeros((3, 1))

## 
for i in range(0, com_xx.shape[0]):
    for j in range(0, com_xx.shape[1]):
        
        ## parameters for classification
        ev = eig_value[i, j, :]
        parmeter_dist[0] =  corner_w - 0.5* np.dot(np.dot(ev-corner_mean,np.linalg.pinv(corner_sigma)) , np.transpose(ev-corner_mean))          
        parmeter_dist[1] = edge_w -  0.5* np.dot ( np.dot(ev-edge_mean,np.linalg.pinv(edge_sigma)) , np.transpose(ev-edge_mean))
        parmeter_dist[2] =  flat_w -  0.5* np.dot ( np.dot(ev-flat_mean,np.linalg.pinv(flat_sigma)) , np.transpose(ev-flat_mean))
        predicted_label[i,j] = np.argmax(parmeter_dist)


        ## Match the predicted label to the groud truth and classify

        ## For Corner 
        if Rv_1[i, j] == 255 and predicted_label[i, j] != ground_truth[i, j]:
            final_prediction[0, i, j] = 255
            false_count[0] += 1
            
        ## For Edge
        if Rv_2[i, j] == 255 and predicted_label[i, j] != ground_truth[i, j]:
            final_prediction[1, i, j] = 255
            false_count[1] += 1
            edge_label[i,j] =255

        ## For Flat Region
        if Rv_3[i, j] == 255 and predicted_label[i, j] != ground_truth[i, j]:
            final_prediction[2, i, j] = 255
            false_count[2] += 1
            flat_label[i,j] = 255

## Confusion Matrix
confusion_matrix_final = np.zeros((3,3))
confusion_matrix_final = confusion_matrix(predicted_label.flatten(), ground_truth.flatten())
print("The Confusion matrix is: \n", confusion_matrix_final)

### Print the error rate
print("Error Rate for the Corner is", 100*(false_count[0])/corner_count)
print("Error Rate for the Edge is ", 100*(false_count[1])/ edge_count)
print("Error Rate for the flat region is ", 100*(false_count[2])/ flat_count)






