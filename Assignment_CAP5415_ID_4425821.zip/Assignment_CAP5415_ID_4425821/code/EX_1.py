import cv2
import numpy as np

img = cv2.imread('image.png')

##### Scaling the image ####
height, width = img.shape[:2]
res = cv2.resize(img,(3*width, 3*height), interpolation = cv2.INTER_CUBIC)

# Write image back to disk
cv2.imwrite('output1.png', res)


###### Rotating the image
M = cv2.getRotationMatrix2D((height / 2, width / 2), 45, 1)   ## Get rotation matrix
res = cv2.warpAffine(img, M, (height, width))                 ## apply it

# Write image back to disk
cv2.imwrite('output2.png', res)


###### Translation of the image
# If the shift is (x, y) then matrix would be
# M = [1 0 x]
#     [0 1 y]
M = np.float32([[1, 0, 30], [0, 1, 50]])   ##
res = cv2.warpAffine(img, M, (height, width))

# Write image back to disk
cv2.imwrite('output3.png', res)
