import numpy as np
import matplotlib.pyplot as plt

X = np.loadtxt('data.txt') #reading in the data points from file
b = np.loadtxt('data_b.txt').reshape(20,1)

MMSE_sol = np.zeros((5,1)) #initializeing the h vector


#calculating the MMSE solution of h using the rule of pseudo-inverse
C = np.dot(np.linalg.inv(np.dot(np.transpose(X) , X)) , np.transpose(X))
MMSE_sol = np.dot(C,b)
error = np.dot(X, MMSE_sol)-b
MMSE_error = np.dot(np.transpose(error), error)
print("MMSE solution:", MMSE_sol)
print("MMSE error", MMSE_error)



### Using Gradient Descent
numIterations = 250     # maximum number of iterations
xTrans = X.transpose()
GD_error = np.zeros((numIterations))
theta = np.random.randn(5,1)   ## initialize the solution
alpha = 0.5			# Learning Rate
for i in range(numIterations):
   hypothesis = np.dot(X, theta)
   loss = hypothesis - b
   GD_error[i] = np.dot(np.transpose(loss), loss)
   cost = np.sum(loss ** 2)
   print("Iteration %d | Cost: %f" % (i, cost))
   ## calculate the gradient
   gradient = np.dot(xTrans, loss)/20
   # update
   theta = theta - alpha * gradient


error = np.dot(X, theta)-b
GD_error_final = np.dot(np.transpose(error), error)
print("Gradient Descent Solution: ",theta)
print("Gradient Descent error", GD_error_final)
plt.plot(GD_error)
plt.show()



